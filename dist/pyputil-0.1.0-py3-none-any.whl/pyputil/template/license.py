#!/usr/bin/env python3

# -*- coding: utf-8 -*-

from typing import Optional, Dict, List, Union, Literal
from datetime import datetime
from pathlib import Path
import re
from enum import Enum

# Supported license types with SPDX identifiers
LICENSE_SPDX = {
    "MIT": "MIT License",
    "Apache-2.0": "Apache License 2.0",
    "GPL-3.0": "GNU General Public License v3.0",
    "GPL-3.0-or-later": "GNU General Public License v3.0 or later",
    "LGPL-3.0": "GNU Lesser General Public License v3.0",
    "BSD-2-Clause": "BSD 2-Clause License",
    "BSD-3-Clause": "BSD 3-Clause License",
    "ISC": "ISC License",
    "MPL-2.0": "Mozilla Public License 2.0",
    "AGPL-3.0": "GNU Affero General Public License v3.0",
    "MIT-0": "MIT No Attribution",
    "Unlicense": "The Unlicense",
    "CC0-1.0": "Creative Commons Zero v1.0 Universal",
    "BSL-1.0": "Boost Software License 1.0",
    "Zlib": "zlib/libpng License",
}

class LicenseTemplate:
    """Container for license template strings with placeholders."""
    
    TEMPLATES = {
        "MIT": """MIT License

Copyright (c) {year} {holder}

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
""",

        "Apache-2.0": """Apache License
Version 2.0, January 2004
http://www.apache.org/licenses/

TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

1. Definitions.

   "License" shall mean the terms and conditions for use, reproduction,
   and distribution as defined by Sections 1 through 9 of this document.

   "Licensor" shall mean the copyright owner or entity authorized by
   the copyright owner that is granting the License.

   "Legal Entity" shall mean the union of the acting entity and all
   other entities that control, are controlled by, or are under common
   control with that entity. For the purposes of this definition,
   "control" means (i) the power, direct or indirect, to cause the
   direction or management of such entity, whether by contract or
   otherwise, or (ii) ownership of fifty percent (50%) or more of the
   outstanding shares, or (iii) beneficial ownership of such entity.

   "You" (or "Your") shall mean an individual or Legal Entity
   exercising permissions granted by this License.

   "Source" form shall mean the preferred form for making modifications,
   including but not limited to software source code, documentation
   source, and configuration files.

   "Object" form shall mean any form resulting from mechanical
   transformation or translation of a Source form, including but
   not limited to compiled object code, generated documentation,
   and conversions to other media types.

   "Work" shall mean the work of authorship, whether in Source or
   Object form, made available under the License, as indicated by a
   copyright notice that is included in or attached to the work
   (an example is provided in the Appendix below).

   "Derivative Works" shall mean any work, whether in Source or Object
   form, that is based on (or derived from) the Work and for which the
   editorial revisions, annotations, elaborations, or other modifications
   represent, as a whole, an original work of authorship. For the purposes
   of this License, Derivative Works shall not include works that remain
   separable from, or merely link (or bind by name) to the interfaces of,
   the Work and Derivative Works thereof.

   "Contribution" shall mean any work of authorship, including
   the original version of the Work and any modifications or additions
   to that Work or Derivative Works thereof, that is intentionally
   submitted to Licensor for inclusion in the Work by the copyright owner
   or by an individual or Legal Entity authorized to submit on behalf of
   the copyright owner. For the purposes of this definition, "submitted"
   means any form of electronic, verbal, or written communication sent
   to the Licensor or its representatives, including but not limited to
   communication on electronic mailing lists, source code control systems,
   and issue tracking systems that are managed by, or on behalf of, the
   Licensor for the purpose of discussing and improving the Work, but
   excluding communication that is conspicuously marked or otherwise
   designated in writing by the copyright owner as "Not a Contribution."

   "Contributor" shall mean Licensor and any individual or Legal Entity
   on behalf of whom a Contribution has been received by Licensor and
   subsequently incorporated within the Work.

2. Grant of Copyright License. Subject to the terms and conditions of
   this License, each Contributor hereby grants to You a perpetual,
   worldwide, non-exclusive, no-charge, royalty-free, irrevocable
   copyright license to reproduce, prepare Derivative Works of,
   publicly display, publicly perform, sublicense, and distribute the
   Work and such Derivative Works in Source or Object form.

3. Grant of Patent License. Subject to the terms and conditions of
   this License, each Contributor hereby grants to You a perpetual,
   worldwide, non-exclusive, no-charge, royalty-free, irrevocable
   (except as stated in this section) patent license to make, have made,
   use, offer to sell, sell, import, and otherwise transfer the Work,
   where such license applies only to those patent claims licensable
   by such Contributor that are necessarily infringed by their
   Contribution(s) alone or by combination of their Contribution(s)
   with the Work to which such Contribution(s) was submitted. If You
   institute patent litigation against any entity (including a
   cross-claim or counterclaim in a lawsuit) alleging that the Work
   or a Contribution incorporated within the Work constitutes direct
   or contributory patent infringement, then any patent licenses
   granted to You under this License for that Work shall terminate
   as of the date such litigation is filed.

4. Redistribution. You may reproduce and distribute copies of the
   Work or Derivative Works thereof in any medium, with or without
   modifications, and in Source or Object form, provided that You
   meet the following conditions:

   (a) You must give any other recipients of the Work or
       Derivative Works a copy of this License; and

   (b) You must cause any modified files to carry prominent notices
       stating that You changed the files; and

   (c) You must retain, in the Source form of any Derivative Works
       that You distribute, all copyright, patent, trademark, and
       attribution notices from the Source form of the Work,
       excluding those notices that do not pertain to any part of
       the Derivative Works; and

   (d) If the Work includes a "NOTICE" text file as part of its
       distribution, then any Derivative Works that You distribute must
       include a readable copy of the attribution notices contained
       within such NOTICE file, excluding those notices that do not
       pertain to any part of the Derivative Works, in at least one
       of the following places: within a NOTICE text file distributed
       as part of the Derivative Works; within the Source form or
       documentation, if provided along with the Derivative Works; or,
       within a display generated by the Derivative Works, if and
       wherever such third-party notices normally appear. The contents
       of the NOTICE file are for informational purposes only and
       do not modify the License. You may add Your own attribution
       notices within Derivative Works that You distribute, alongside
       or as an addendum to the NOTICE text from the Work, provided
       that such additional attribution notices cannot be construed
       as modifying the License.

   You may add Your own copyright statement to Your modifications and
   may provide additional or different license terms and conditions
   for use, reproduction, or distribution of Your modifications, or
   for any such Derivative Works as a whole, provided Your use,
   reproduction, and distribution of the Work otherwise complies with
   the conditions stated in this License.

5. Submission of Contributions. Unless You explicitly state otherwise,
   any Contribution intentionally submitted for inclusion in the Work
   by You to the Licensor shall be under the terms and conditions of
   this License, without any additional terms or conditions.
   Notwithstanding the above, nothing herein shall supersede or modify
   the terms of any separate license agreement you may have executed
   with Licensor regarding such Contributions.

6. Trademarks. This License does not grant permission to use the trade
   names, trademarks, service marks, or product names of the Licensor,
   except as required for reasonable and customary use in describing the
   origin of the Work and reproducing the content of the NOTICE file.

7. Disclaimer of Warranty. Unless required by applicable law or
   agreed to in writing, Licensor provides the Work (and each
   Contributor provides its Contributions) on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
   implied, including, without limitation, any warranties or conditions
   of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
   PARTICULAR PURPOSE. You are solely responsible for determining the
   appropriateness of using or redistributing the Work and assume any
   risks associated with Your exercise of permissions under this License.

8. Limitation of Liability. In no event and under no legal theory,
   whether in tort (including negligence), contract, or otherwise,
   unless required by applicable law (such as deliberate and grossly
   negligent acts) or agreed to in writing, shall any Contributor be
   liable to You for damages, including any direct, indirect, special,
   incidental, or consequential damages of any character arising as a
   result of this License or out of the use or inability to use the
   Work (including but not limited to damages for loss of goodwill,
   work stoppage, computer failure or malfunction, or any and all
   other commercial damages or losses), even if such Contributor
   has been advised of the possibility of such damages.

9. Accepting Warranty or Additional Liability. While redistributing
   the Work or Derivative Works thereof, You may choose to offer,
   and charge a fee for, acceptance of support, warranty, indemnity,
   or other liability obligations and/or rights consistent with this
   License. However, in accepting such obligations, You may act only
   on Your own behalf and on Your sole responsibility, not on behalf
   of any other Contributor, and only if You agree to indemnify,
   defend, and hold each Contributor harmless for any liability
   incurred by, or claims asserted against, such Contributor by reason
   of your accepting any such warranty or additional liability.

END OF TERMS AND CONDITIONS

Copyright {year} {holder}

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
""",

        "GPL-3.0": """GNU GENERAL PUBLIC LICENSE
Version 3, 29 June 2007

Copyright (C) 2007 Free Software Foundation, Inc. <http://fsf.org/>
Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble

The GNU General Public License is a free, copyleft license for
software and other kinds of works.

The licenses for most software and other practical works are designed
to take away your freedom to share and change the works. By contrast,
the GNU General Public License is intended to guarantee your freedom to
share and change all versions of a program--to make sure it remains free
software for all its users. We, the Free Software Foundation, use the
GNU General Public License for most of our software; it applies also to
any other work released this way by its authors. You can apply it to
your programs, too.

When we speak of free software, we are referring to freedom, not
price. Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
them if you wish), that you receive source code or can get it if you
want it, that you can change the software or use pieces of it in new
free programs, and that you know you can do these things.

To protect your rights, we need to prevent others from denying you
these rights or asking you to surrender the rights. Therefore, you have
certain responsibilities if you distribute copies of the software, or if
you modify it: responsibilities to respect the freedom of others.

For example, if you distribute copies of such a program, whether
gratis or for a fee, you must pass on to the recipients the same
freedoms that you received. You must make sure that they, too, receive
or can get the source code. And you must show them these terms so they
know their rights.

Developers that use the GNU GPL protect your rights with two steps:
(1) assert copyright on the software, and (2) offer you this License
giving you legal permission to copy, distribute and/or modify it.

For the developers' and authors' protection, the GPL clearly explains
that there is no warranty for this free software. For both users' and
authors' sake, the GPL requires that modified versions be marked as
changed, so that their problems will not be attributed erroneously to
authors of previous versions.

Some devices are designed to deny users access to install or run
modified versions of the software inside them, although the manufacturer
can do so. This is fundamentally incompatible with the aim of
protecting users' freedom to change the software. The systematic
pattern of such abuse occurs in the area of products for individuals to
use, which is precisely where it is most unacceptable. Therefore, we
have designed this version of the GPL to prohibit the practice for those
products. If such problems arise substantially in other domains, we
stand ready to extend this provision to those domains in future versions
of the GPL, as needed to protect the freedom of users.

Finally, every program is threatened constantly by software patents.
States should not allow patents to restrict development and use of
software on general-purpose computers, but in those that do, we wish to
avoid the special danger that patents applied to a free program could
make it effectively proprietary. To prevent this, the GPL assures that
patents cannot be used to render the program non-free.

The precise terms and conditions for copying, distribution and
modification follow.

TERMS AND CONDITIONS

0. Definitions.

   "This License" refers to version 3 of the GNU General Public License.

   "Copyright" also means copyright-like laws that apply to other kinds of
   works, such as semiconductor masks.

   "The Program" refers to any copyrightable work licensed under this
   License. Each licensee is addressed as "you". "Licensees" and
   "recipients" may be individuals or organizations.

   To "modify" a work means to copy from or adapt all or part of the work
   in a fashion requiring copyright permission, other than the making of an
   exact copy. The resulting work is called a "modified version" of the
   earlier work or a work "based on" the earlier work.

   A "covered work" means either the unmodified Program or a work based
   on the Program.

   To "propagate" a work means to do anything with it that, without
   permission, would make you directly or secondarily liable for
   infringement under applicable copyright law, except executing it on a
   computer or modifying a private copy. Propagation includes copying,
   distribution (with or without modification), making available to the
   public, and in some countries other activities as well.

   To "convey" a work means any kind of propagation that enables other
   parties to make or receive copies. Mere interaction with a user through
   a computer network, with no transfer of a copy, is not conveying.

   An interactive user interface displays "Appropriate Legal Notices"
   to the extent that it includes a convenient and prominently visible
   feature that (1) displays an appropriate copyright notice, and (2)
   tells the user that there is no warranty for the work (except to the
   extent that warranties are provided), that licensees may convey the
   work under this License, and how to view a copy of this License. If
   the interface presents a list of user commands or options, such as a
   menu, a prominent item in the list meets this criterion.

1. Source Code.

   The "source code" for a work means the preferred form of the work
   for making modifications to it. "Object code" means any non-source
   form of a work.

   A "Standard Interface" means an interface that either is an official
   standard defined by a recognized standards body, or, in the case of
   interfaces specified for a particular programming language, one that
   is widely used among developers working in that language.

   The "System Libraries" of an executable work include anything, other
   than the work as a whole, that (a) is included in the normal form of
   packaging a Major Component, but which is not part of that Major
   Component, and (b) serves only to enable use of the work with that
   Major Component, or to implement a Standard Interface for which an
   implementation is available to the public in source code form. A
   "Major Component", in this context, means a major essential component
   (kernel, window system, and so on) of the specific operating system
   (if any) on which the executable work runs, or a compiler used to
   produce the work, or an object code interpreter used to run it.

   The "Corresponding Source" for a work in object code form means all
   the source code needed to generate, install, and (for an executable
   work) run the object code and to modify the work, including scripts to
   control those activities. However, it does not include the work's
   System Libraries, or general-purpose tools or generally available free
   programs which are used unmodified in performing those activities but
   which are not part of the work. For example, Corresponding Source
   includes interface definition files associated with source files for
   the work, and the source code for shared libraries and dynamically
   linked subprograms that the work is specifically designed to require,
   such as by intimate data communication or control flow between those
   subprograms and other parts of the work.

   The Corresponding Source need not include anything that users
   can regenerate automatically from other parts of the Corresponding
   Source.

   The Corresponding Source for a work in source code form is that
   same work.

2. Basic Permissions.

   All rights granted under this License are granted for the term of
   copyright on the Program, and are irrevocable provided the stated
   conditions are met. This License explicitly affirms your unlimited
   permission to run the unmodified Program. The output from running a
   covered work is covered by this License only if the output, given its
   content, constitutes a covered work. This License acknowledges your
   rights of fair use or other equivalent, as provided by copyright law.

   You may make, run and propagate covered works that you do not
   convey, without conditions so long as your license otherwise remains
   in force. You may convey covered works to others for the sole purpose
   of having them make modifications exclusively for you, or provide you
   with facilities for running those works, provided that you comply with
   the terms of this License in conveying all material for which you do
   not control copyright. Those thus making or running the covered works
   for you must do so exclusively on your behalf, under your direction
   and control, on terms that prohibit them from making any copies of
   your copyrighted material outside their relationship with you.

   Conveying under any other circumstances is permitted solely under
   the conditions stated below. Sublicensing is not allowed; section 10
   makes it unnecessary.

3. Protecting Users' Legal Rights From Anti-Circumvention Law.

   No covered work shall be deemed part of an effective technological
   measure under any applicable law fulfilling obligations under article
   11 of the WIPO copyright treaty adopted on 20 December 1996, or
   similar laws prohibiting or restricting circumvention of such
   measures.

   When you convey a covered work, you waive any legal power to forbid
   circumvention of technological measures to the extent such circumvention
   is effected by exercising rights under this License with respect to
   the covered work, and you disclaim any intention to limit operation or
   modification of the work as a means of enforcing, against the work's
   users, your or third parties' legal rights to forbid circumvention of
   technological measures.

4. Conveying Verbatim Copies.

   You may convey verbatim copies of the Program's source code as you
   receive it, in any medium, provided that you conspicuously and
   appropriately publish on each copy an appropriate copyright notice;
   keep intact all notices stating that this License and any
   non-permissive terms added in accord with section 7 apply to the code;
   keep intact all notices of the absence of any warranty; and give all
   recipients a copy of this License along with the Program.

   You may charge any price or no price for each copy that you convey,
   and you may offer support or warranty protection for a fee.

5. Conveying Modified Source Versions.

   You may convey a work based on the Program, or the modifications to
   produce it from the Program, in the form of source code under the
   terms of section 4, provided that you also meet all of these conditions:

   a) The work must carry prominent notices stating that you modified
       it, and giving a relevant date.

   b) The work must carry prominent notices stating that it is
       released under this License and any conditions added under section
       7. This requirement modifies the requirement in section 4 to
       "keep intact all notices".

   c) You must license the entire work, as a whole, under this
       License to anyone who comes into possession of a copy. This
       License will therefore apply, along with any applicable section 7
       additional terms, to the whole of the work, and all its parts,
       regardless of how they are packaged. This License gives no
       permission to license the work in any other way, but it does not
       invalidate such permission if you have separately received it.

   d) If the work has interactive user interfaces, each must display
       Appropriate Legal Notices; however, if the Program has interactive
       interfaces that do not display Appropriate Legal Notices, your
       work need not make them do so.

   A compilation of a covered work with other separate and independent
   works, which are not by their nature extensions of the covered work,
   and which are not combined with it such as to form a larger program,
   in or on a volume of a storage or distribution medium, is called an
   "aggregate" if the compilation and its resulting copyright are not
   used to limit the access or legal rights of the compilation's users
   beyond what the individual works permit. Inclusion of a covered work
   in an aggregate does not cause this License to apply to the other
   parts of the aggregate.

6. Conveying Non-Source Forms.

   You may convey a covered work in object code form under the terms
   of sections 4 and 5, provided that you also convey the
   machine-readable Corresponding Source under the terms of this License,
   in one of these ways:

   a) Convey the object code in, or embodied in, a physical product
       (including a physical distribution medium), accompanied by the
       Corresponding Source fixed on a durable physical medium
       customarily used for software interchange.

   b) Convey the object code in, or embodied in, a physical product
       (including a physical distribution medium), accompanied by a
       written offer, valid for at least three years and valid for as
       long as you offer spare parts or customer support for that product
       model, to give anyone who possesses the object code either (1) a
       copy of the Corresponding Source for all the software in the
       product that is covered by this License, on a durable physical
       medium customarily used for software interchange, for a price no
       more than your reasonable cost of physically performing this
       conveying of source, or (2) access to copy the
       Corresponding Source from a network server at no charge.

   c) Convey individual copies of the object code with a copy of the
       written offer to provide the Corresponding Source. This
       alternative is allowed only occasionally and noncommercially, and
       only if you received the object code with such an offer, in accord
       with subsection 6b.

   d) Convey the object code by offering access from a designated
       place (gratis or for a charge), and offer equivalent access to the
       Corresponding Source in the same way through the same place at no
       further charge. You need not require recipients to copy the
       Corresponding Source along with the object code. If the place to
       copy the object code is a network server, the Corresponding Source
       may be on a different server (operated by you or a third party)
       that supports equivalent copying facilities, provided you maintain
       clear directions next to the object code saying where to find the
       Corresponding Source. Regardless of what server hosts the
       Corresponding Source, you remain obligated to ensure that it is
       available for as long as needed to satisfy these requirements.

   e) Convey the object code using peer-to-peer transmission, provided
       you inform other peers where the object code and Corresponding
       Source of the work are being offered to the general public at no
       charge under subsection 6d.

   A separable portion of the object code, whose source code is excluded
   from the Corresponding Source as a System Library, need not be
   included in conveying the object code work.

   A "User Product" is either (1) a "consumer product", which means any
   tangible personal property which is normally used for personal, family,
   or household purposes, or (2) anything designed or sold for incorporation
   into a dwelling. In determining whether a product is a consumer product,
   doubtful cases shall be resolved in favor of coverage. For a particular
   product received by a particular user, "normally used" refers to a
   typical or common use of that class of product, regardless of the status
   of the particular user or of the way in which the particular user
   actually uses, or expects or is expected to use, the product. A product
   is a consumer product regardless of whether the product has substantial
   commercial, industrial or non-consumer uses, unless such uses represent
   the only significant mode of use of the product.

   "Installation Information" for a User Product means any methods,
   procedures, authorization keys, or other information required to install
   and execute modified versions of a covered work in that User Product from
   a modified version of its Corresponding Source. The information must
   suffice to ensure that the continued functioning of the modified object
   code is in no case prevented or interfered with solely because
   modification has been made.

   If you convey an object code work under this section in, or with, or
   specifically for use in, a User Product, and the conveying occurs as
   part of a transaction in which the right of possession and use of the
   User Product is transferred to the recipient in perpetuity or for a
   fixed term (regardless of how the transaction is characterized), the
   Corresponding Source conveyed under this section must be accompanied
   by the Installation Information. But this requirement does not apply
   if neither you nor any third party retains the ability to install
   modified object code on the User Product (for example, the work has
   been installed in ROM).

   The requirement to provide Installation Information does not include a
   requirement to continue to provide support service, warranty, or updates
   for a work that has been modified or installed by the recipient, or for
   the User Product in which it has been modified or installed. Access to a
   network may be denied when the modification itself materially and
   adversely affects the operation of the network or violates the rules and
   protocols for communication across the network.

   Corresponding Source conveyed, and Installation Information provided,
   in accord with this section must be in a format that is publicly
   documented (and with an implementation available to the public in
   source code form), and must require no special password or key for
   unpacking, reading or copying.

7. Additional Terms.

   "Additional permissions" are terms that supplement the terms of this
   License by making exceptions from one or more of its conditions.
   Additional permissions that are applicable to the entire Program shall
   be treated as though they were included in this License, to the extent
   that they are valid under applicable law. If additional permissions
   apply only to part of the Program, that part may be used separately
   under those permissions, but the entire Program remains governed by
   this License without regard to the additional permissions.

   When you convey a copy of a covered work, you may at your option
   remove any additional permissions from that copy, or from any part of
   it. (Additional permissions may be written to require their own
   removal in certain cases when you modify the work.) You may place
   additional permissions on material, added by you to a covered work,
   for which you have or can give appropriate copyright permission.

   Notwithstanding any other provision of this License, for material you
   add to a covered work, you may (if authorized by the copyright holders of
   that material) supplement the terms of this License with terms:

   a) Disclaiming warranty or limiting liability differently from the
       terms of sections 15 and 16 of this License; or

   b) Requiring preservation of specified reasonable legal notices or
       author attributions in that material or in the Appropriate Legal
       Notices displayed by works containing it; or

   c) Prohibiting misrepresentation of the origin of that material, or
       requiring that modified versions of such material be marked in
       reasonable ways as different from the original version; or

   d) Limiting the use for publicity purposes of names of licensors or
       authors of the material; or

   e) Declining to grant rights under trademark law for use of some
       trade names, trademarks, or service marks; or

   f) Requiring indemnification of licensors and authors of that
       material by anyone who conveys the material (or modified versions of
       it) with contractual assumptions of liability to the recipient, for
       any liability that these contractual assumptions directly impose on
       those licensors and authors.

   All other non-permissive additional terms are considered "further
   restrictions" within the meaning of section 10. If the Program as you
   received it, or any part of it, contains a notice stating that it is
   governed by this License along with a term that is a further
   restriction, you may remove that term. If a license document contains
   a further restriction but permits relicensing or conveying under this
   License, you may add to a covered work material governed by the terms
   of that license document, provided that the further restriction does
   not survive such relicensing or conveying.

   If you add terms to a covered work in accord with this section, you
   must place, in the relevant source files, a statement of the
   additional terms that apply to those files, or a notice indicating
   where to find the applicable terms.

   Additional terms, permissive or non-permissive, may be stated in the
   form of a separately written license, or stated as exceptions;
   the above requirements apply either way.

8. Termination.

   You may not propagate or modify a covered work except as expressly
   provided under this License. Any attempt otherwise to propagate or
   modify it is void, and will automatically terminate your rights under
   this License (including any patent licenses granted under the third
   paragraph of section 11).

   However, if you cease all violation of this License, then your
   license from a particular copyright holder is reinstated (a)
   provisionally, unless and until the copyright holder explicitly and
   finally terminates your license, and (b) permanently, if the copyright
   holder fails to notify you of the violation by some reasonable means
   prior to 60 days after the cessation.

   Moreover, your license from a particular copyright holder is
   reinstated permanently if the copyright holder notifies you of the
   violation by some reasonable means, this is the first time you have
   received notice of violation of this License (for any work) from that
   copyright holder, and you cure the violation prior to 30 days after
   your receipt of the notice.

   Termination of your rights under this section does not terminate the
   licenses of parties who have received copies or rights from you under
   this License. If your rights have been terminated and not permanently
   reinstated, you do not qualify to receive new licenses for the same
   material under section 10.

9. Acceptance Not Required for Having Copies.

   You are not required to accept this License in order to receive or
   run a copy of the Program. Ancillary propagation of a covered work
   occurring solely as a consequence of using peer-to-peer transmission
   to receive a copy likewise does not require acceptance. However,
   nothing other than this License grants you permission to propagate or
   modify any covered work. These actions infringe copyright if you do
   not accept this License. Therefore, by modifying or propagating a
   covered work, you indicate your acceptance of this License to do so.

10. Automatic Licensing of Downstream Recipients.

    Each time you convey a covered work, the recipient automatically
    receives a license from the original licensors, to run, modify and
    propagate that work, subject to this License. You are not responsible
    for enforcing compliance by third parties with this License.

    An "entity transaction" is a transaction transferring control of an
    organization, or substantially all assets of one, or subdividing an
    organization, or merging organizations. If propagation of a covered
    work results from an entity transaction, each party to that
    transaction who receives a copy of the work also receives whatever
    licenses to the work the party's predecessor in interest had or could
    give under the previous paragraph, plus a right to possession of the
    Corresponding Source of the work from the predecessor in interest, if
    the predecessor has it or can get it with reasonable efforts.

    You may not impose any further restrictions on the exercise of the
    rights granted or affirmed under this License. For example, you may
    not impose a license fee, royalty, or other charge for exercise of
    rights granted under this License, and you may not initiate litigation
    (including a cross-claim or counterclaim in a lawsuit) alleging that
    any patent claim is infringed by making, using, selling, offering for
    sale, or importing the Program or any portion of it.

11. Patents.

    A "contributor" is a copyright holder who authorizes use under this
    License of the Program or a work on which the Program is based. The
    work thus licensed is called the contributor's "contributor version".

    A contributor's "essential patent claims" are all patent claims
    owned or controlled by the contributor, whether already acquired or
    hereafter acquired, that would be infringed by some manner, permitted
    by this License, of making, using, or selling its contributor version,
    but do not include claims that would be infringed only as a
    consequence of further modification of the contributor version. For
    purposes of this definition, "control" includes the right to grant
    patent sublicenses in a manner consistent with the requirements of
    this License.

    Each contributor grants you a non-exclusive, worldwide, royalty-free
    patent license under the contributor's essential patent claims, to
    make, use, sell, offer for sale, import and otherwise run, modify and
    propagate the contents of its contributor version.

    In the following three paragraphs, a "patent license" is any express
    agreement or commitment, however denominated, not to enforce a patent
    (such as an express permission to practice a patent or covenant not to
    sue for patent infringement). To "grant" such a patent license to a
    party means to make such an agreement or commitment not to enforce a
    patent against the party.

    If you convey a covered work, knowingly relying on a patent license,
    and the Corresponding Source of the work is not available for anyone
    to copy, free of charge and under the terms of this License, through a
    publicly available network server or other readily accessible means,
    then you must either (1) cause the Corresponding Source to be so
    available, or (2) arrange to deprive yourself of the benefit of the
    patent license for this particular work, or (3) arrange, in a manner
    consistent with the requirements of this License, to extend the patent
    license to downstream recipients. "Knowingly relying" means you have
    actual knowledge that, but for the patent license, your conveying the
    covered work in a country, or your recipient's use of the covered work
    in a country, would infringe one or more identifiable patents in that
    country that you have reason to believe are valid.

    If, pursuant to or in connection with a single transaction or
    arrangement, you convey, or propagate by procuring conveyance of, a
    covered work, and grant a patent license to some of the parties
    receiving the covered work authorizing them to use, propagate, modify
    or convey a specific copy of the covered work, then the patent license
    you grant is automatically extended to all recipients of the covered
    work and works based on it.

    A patent license is "discriminatory" if it does not include within
    the scope of its coverage, prohibits the exercise of, or is
    conditioned on the non-exercise of one or more of the rights that are
    specifically granted under this License. You may not convey a covered
    work if you are a party to an arrangement with a third party that is
    in the business of distributing software, under which you make payment
    to the third party based on the extent of your activity of conveying
    the work, and under which the third party grants, to any of the
    parties who would receive the covered work from you, a discriminatory
    patent license (a) in connection with copies of the covered work
    conveyed by you (or copies made from those copies), or (b) primarily
    for and in connection with specific products or compilations that
    contain the covered work, unless you entered into that arrangement,
    or that patent license was granted, prior to 28 March 2007.

    Nothing in this License shall be construed as excluding or limiting
    any implied license or other defenses to infringement that may
    otherwise be available to you under applicable patent law.

12. No Surrender of Others' Freedom.

    If conditions are imposed on you (whether by court order, agreement or
    otherwise) that contradict the conditions of this License, they do not
    excuse you from the conditions of this License. If you cannot convey a
    covered work so as to satisfy simultaneously your obligations under this
    License and any other pertinent obligations, then as a consequence you may
    not convey it at all. For example, if you agree to terms that obligate you
    to collect a royalty for further conveying from those to whom you convey
    the Program, the only way you could satisfy both those terms and this
    License would be to refrain entirely from conveying the Program.

13. Use with the GNU Affero General Public License.

    Notwithstanding any other provision of this License, you have
    permission to link or combine any covered work with a work licensed
    under version 3 of the GNU Affero General Public License into a single
    combined work, and to convey the resulting work. The terms of this
    License will continue to apply to the part which is the covered work,
    but the special requirements of the GNU Affero General Public License,
    section 13, concerning interaction through a network will apply to the
    combination as such.

14. Revised Versions of this License.

    The Free Software Foundation may publish revised and/or new versions of
    the GNU General Public License from time to time. Such new versions will
    be similar in spirit to the present version, but may differ in detail to
    address new problems or concerns.

    Each version is given a distinguishing version number. If the
    Program specifies that a certain numbered version of the GNU General
    Public License "or any later version" applies to it, you have the
    option of following the terms and conditions either of that numbered
    version or of any later version published by the Free Software
    Foundation. If the Program does not specify a version number of the
    GNU General Public License, you may choose any version ever published
    by the Free Software Foundation.

    If the Program specifies that a proxy can decide which future
    versions of the GNU General Public License can be used, that proxy's
    public statement of acceptance of a version permanently authorizes you
    to choose that version for the Program.

    Later license versions may give you additional or different
    permissions. However, no additional obligations are imposed on any
    author or copyright holder as a result of your choosing to follow a
    later version.

15. Disclaimer of Warranty.

    THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY
    APPLICABLE LAW. EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT
    HOLDERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY
    OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO,
    THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
    PURPOSE. THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE PROGRAM
    IS WITH YOU. SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF
    ALL NECESSARY SERVICING, REPAIR OR CORRECTION.

16. Limitation of Liability.

    IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
    WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MODIFIES AND/OR CONVEYS
    THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES, INCLUDING ANY
    GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE
    USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF
    DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD
    PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS),
    EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF
    SUCH DAMAGES.

17. Interpretation of Sections 15 and 16.

    If the disclaimer of warranty and limitation of liability provided
    above cannot be given local legal effect according to their terms,
    reviewing courts shall apply local law that most closely approximates
    an absolute waiver of all civil liability in connection with the
    Program, unless a warranty or assumption of liability accompanies a
    copy of the Program in return for a fee.

END OF TERMS AND CONDITIONS

Copyright (C) {year}  {holder}

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
""",

        "BSD-3-Clause": """BSD 3-Clause License

Copyright (c) {year}, {holder}
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its
   contributors may be used to endorse or promote products derived from
   this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
""",

        "BSD-2-Clause": """BSD 2-Clause License

Copyright (c) {year}, {holder}
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
""",

        "ISC": """ISC License

Copyright (c) {year} {holder}

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
""",

        "MPL-2.0": """Mozilla Public License Version 2.0
==================================

1. Definitions
--------------

1.1. "Contributor"
    means each individual or legal entity that creates, contributes to
    the creation of, or owns Covered Software.

1.2. "Contributor Version"
    means the combination of the Contributions of others (if any) used
    by a Contributor and that particular Contributor's Contribution.

1.3. "Contribution"
    means Covered Software of a particular Contributor.

1.4. "Covered Software"
    means Source Code Form to which the initial Contributor has attached
    the notice in Exhibit A, the Executable Form of such Source Code
    Form, and Modifications of such Source Code Form, in each case
    including portions thereof.

1.5. "Incompatible With Secondary Licenses"
    means

    (a) that the initial Contributor has attached the notice described
        in Exhibit B to the Covered Software; or

    (b) that the Covered Software was made available under the terms of
        version 1.1 or earlier of the License, but not also under the
        terms of a Secondary License.

1.6. "Executable Form"
    means any form of the work other than Source Code Form.

1.7. "Larger Work"
    means a work that combines Covered Software with other material, in 
    a separate file or files, that is not Covered Software.

1.8. "License"
    means this document.

1.9. "Licensable"
    means having the right to grant, to the maximum extent possible,
    whether at the time of the initial grant or subsequently, any and
    all of the rights conveyed by this License.

1.10. "Modifications"
    means any of the following:

    (a) any file in Source Code Form that results from an addition to,
        deletion from, or modification of the contents of Covered
        Software; or

    (b) any new file in Source Code Form that contains any Covered
        Software.

1.11. "Patent Claims" of a Contributor
    means any patent claim(s), including without limitation, method,
    process, and apparatus claims, in any patent Licensable by such
    Contributor that would be infringed, but for the grant of the
    License, by the making, using, selling, offering for sale, having
    made, import, or transfer of either its Contributions or its
    Contributor Version.

1.12. "Secondary License"
    means either the GNU General Public License, Version 2.0, the GNU
    Lesser General Public License, Version 2.1, the GNU Affero General
    Public License, Version 3.0, or any later versions of those
    licenses.

1.13. "Source Code Form"
    means the form of the work preferred for making modifications.

1.14. "You" (or "Your")
    means an individual or a legal entity exercising rights under this
    License. For legal entities, "You" includes any entity that
    controls, is controlled by, or is under common control with You. For
    purposes of this definition, "control" means (a) the power, direct
    or indirect, to cause the direction or management of such entity,
    whether by contract or otherwise, or (b) ownership of more than
    fifty percent (50%) of the outstanding shares or beneficial
    ownership of such entity.

2. License Grants and Conditions
--------------------------------

2.1. Grants

Each Contributor hereby grants You a world-wide, royalty-free,
non-exclusive license:

(a) under intellectual property rights (other than patent or trademark)
    Licensable by such Contributor to use, reproduce, make available,
    modify, display, perform, distribute, and otherwise exploit its
    Contributions, either on an unmodified basis, with Modifications, or
    as part of a Larger Work; and

(b) under Patent Claims of such Contributor to make, use, sell, offer
    for sale, have made, import, and otherwise transfer either its
    Contributions or its Contributor Version.

2.2. Effective Date

The licenses granted in Section 2.1 with respect to any Contribution
become effective for each Contribution on the date the Contributor first
distributes such Contribution.

2.3. Limitations on Grant Scope

The licenses granted in this Section 2 are the only rights granted under
this License. No additional rights or licenses will be implied from the
distribution or licensing of Covered Software under this License.
Notwithstanding Section 2.1(b) above, no patent license is granted by a
Contributor:

(a) for any code that a Contributor has removed from Covered Software;
    or

(b) for infringements caused by: (i) Your and any other third party's
    modifications of Covered Software, or (ii) the combination of its
    Contributions with other software (except as part of its Contributor
    Version); or

(c) under Patent Claims infringed by Covered Software in the absence of
    its Contributions.

This License does not grant any rights in the trademarks, service marks,
or logos of any Contributor (except as may be necessary to comply with
the notice requirements in Section 3.4).

2.4. Subsequent Licenses

No Contributor makes additional grants as a result of Your choice to
distribute the Covered Software under a subsequent version of this
License (see Section 10.2) or under the terms of a Secondary License (if
permitted under the terms of Section 3.3).

2.5. Representation

Each Contributor represents that the Contributor believes its
Contributions are its original creation(s) or it has sufficient rights
to grant the rights to its Contributions conveyed by this License.

2.6. Fair Use

This License is not intended to limit any rights You have under
applicable copyright doctrines of fair use, fair dealing, or other
equivalents.

2.7. Conditions

Sections 3.1, 3.2, 3.3, and 3.4 are conditions of the licenses granted
in Section 2.1.

3. Responsibilities
-------------------

3.1. Distribution of Source Form

All distribution of Covered Software in Source Code Form, including any
Modifications that You create or to which You contribute, must be under
the terms of this License. You must inform recipients that the Source
Code Form of the Covered Software is governed by the terms of this
License, and how they can obtain a copy of this License. You may not
attempt to alter or restrict the recipients' rights in the Source Code
Form.

3.2. Distribution of Executable Form

If You distribute Covered Software in Executable Form then:

(a) such Covered Software must also be made available in Source Code
    Form, as described in Section 3.1, and You must inform recipients of
    the Executable Form how they can obtain a copy of such Source Code
    Form by reasonable means in a timely manner, at a charge no more
    than the cost of distribution to the recipient; and

(b) You may distribute such Executable Form under the terms of this
    License, or sublicense it under different terms, provided that the
    license for the Executable Form does not attempt to limit or alter
    the recipients' rights in the Source Code Form under this License.

3.3. Distribution of a Larger Work

You may create and distribute a Larger Work under terms of Your choice,
provided that You also comply with the requirements of this License for
the Covered Software. If the Larger Work is a combination of Covered
Software with a work governed by one or more Secondary Licenses, and the
Covered Software is not Incompatible With Secondary Licenses, this
License permits You to additionally distribute such Covered Software
under the terms of such Secondary License(s), so that the recipient of
the Larger Work may, at their option, further distribute the Covered
Software under the terms of either this License or such Secondary
License(s).

3.4. Notices

You may not remove or alter the substance of any license notices
(including copyright notices, patent notices, disclaimers of warranty,
or limitations of liability) contained within the Source Code Form of
the Covered Software, except that You may alter any license notices to
the extent required to remedy known factual inaccuracies.

3.5. Application of Additional Terms

You may choose to offer, and to charge a fee for, warranty, support,
indemnity or liability obligations to one or more recipients of Covered
Software. However, You may do so only on Your own behalf, and not on
behalf of any Contributor. You must make it absolutely clear that any
such warranty, support, indemnity, or liability obligation is offered by
You alone, and You hereby agree to indemnify every Contributor for any
liability incurred by such Contributor as a result of warranty, support,
indemnity or liability terms You offer. You may include additional
disclaimers of warranty and limitations of liability specific to any
jurisdiction.

4. Inability to Comply Due to Statute or Regulation
---------------------------------------------------

If it is impossible for You to comply with any of the terms of this
License with respect to some or all of the Covered Software due to
statute, judicial order, or regulation then You must: (a) comply with
the terms of this License to the maximum extent possible; and (b)
describe the limitations and the code they affect. Such description must
be placed in a text file included with all distributions of the Covered
Software under this License. Except to the extent prohibited by statute
or regulation, such description must be sufficiently detailed for a
recipient of ordinary skill to be able to understand it.

5. Termination
--------------

5.1. The rights granted under this License will terminate automatically
if You fail to comply with any of its terms. However, if You become
compliant, then the rights granted under this License from a particular
Contributor are reinstated (a) provisionally, unless and until such
Contributor explicitly and finally terminates Your grants, and (b) on an
ongoing basis, if such Contributor fails to notify You of the
non-compliance by some reasonable means prior to 60 days after You have
come back into compliance. Moreover, Your grants from a particular
Contributor are reinstated on an ongoing basis if such Contributor
notifies You of the non-compliance by some reasonable means, this is the
first time You have received notice of non-compliance with this License
from such Contributor, and You become compliant prior to 30 days after
Your receipt of the notice.

5.2. If You initiate litigation against any entity by asserting a patent
infringement claim (excluding declaratory judgment actions,
counter-claims, and cross-claims) alleging that a Contributor Version
directly or indirectly infringes any patent, then the rights granted to
You by any and all Contributors for the Covered Software under Section
2.1 of this License shall terminate.

5.3. In the event of termination under Sections 5.1 or 5.2 above, all
end user license agreements (excluding distributors and resellers) which
have been validly granted by You or Your distributors under this License
prior to termination shall survive termination.

6. Disclaimer of Warranty
-------------------------

Covered Software is provided under this License on an "as is" basis,
without warranty of any kind, either expressed, implied, or statutory,
including, without limitation, warranties that the Covered Software is
free of defects, merchantable, fit for a particular purpose or
non-infringing. The entire risk as to the quality and performance of the
Covered Software is with You. Should any Covered Software prove
defective in any respect, You (not any Contributor) assume the cost of
any necessary servicing, repair, or correction. This disclaimer of
warranty constitutes an essential part of this License. No use of any
Covered Software is authorized under this License except under this
disclaimer.

7. Limitation of Liability
--------------------------

Under no circumstances and under no legal theory, whether tort
(including negligence), contract, or otherwise, shall any Contributor,
or anyone who distributes Covered Software as permitted above, be liable
to You for any direct, indirect, special, incidental, or consequential
damages of any character including, without limitation, damages for lost
profits, loss of goodwill, work stoppage, computer failure or
malfunction, or any and all other commercial damages or losses, even if
such party shall have been informed of the possibility of such damages.
This limitation of liability shall not apply to liability for death or
personal injury resulting from such party's negligence to the extent
applicable law prohibits such limitation. Some jurisdictions do not
allow the exclusion or limitation of incidental or consequential
damages, so this exclusion and limitation may not apply to You.

8. Litigation
-------------

Any litigation relating to this License may be brought only in the
courts of a jurisdiction where the defendant maintains its principal
place of business and such litigation shall be governed by laws of that
jurisdiction, without reference to its conflict-of-law provisions.
Nothing in this Section shall prevent a party's ability to bring
cross-claims or counter-claims.

9. Miscellaneous
----------------

This License represents the complete agreement concerning the subject
matter hereof. If any provision of this License is held to be
unenforceable, such provision shall be reformed only to the extent
necessary to make it enforceable. Any law or regulation which provides
that the language of a contract shall be construed against the drafter
shall not be used to construe this License against a Contributor.

10. Versions of the License
---------------------------

10.1. New Versions

Mozilla Foundation is the license steward. Except as provided in Section
10.3, no one other than the license steward has the right to modify or
publish new versions of this License. Each version will be given a
distinguishing version number.

10.2. Effect of New Versions

You may distribute the Covered Software under the terms of the version
of the License under which You originally received the Covered Software,
or under the terms of any subsequent version published by the license
steward.

10.3. Modified Versions

If you create software not governed by this License, and you want to
create a new license for such software, you may create and use a
modified version of this License if you rename the license and remove
any references to the name of the license steward (except to note that
such modified license differs from this License).

10.4. Distributing Source Code Form that is Incompatible With Secondary
Licenses

If You choose to distribute Source Code Form that is Incompatible With
Secondary Licenses under the terms of this version of the License, the
notice described in Exhibit B of this License must be attached.

Exhibit A - Source Code Form License Notice
-------------------------------------------

  This Source Code Form is subject to the terms of the Mozilla Public
  License, v. 2.0. If a copy of the MPL was not distributed with this
  file, You can obtain one at http://mozilla.org/MPL/2.0/.

If it is not possible or desirable to put the notice in a particular
file, then You may include the notice in a location (such as a LICENSE
file in a relevant directory) where a recipient would be likely to look
for such a notice.

You may add additional accurate notices of copyright ownership.

Exhibit B - "Incompatible With Secondary Licenses" Notice
---------------------------------------------------------

  This Source Code Form is "Incompatible With Secondary Licenses", as
  defined by the Mozilla Public License, v. 2.0.

Copyright (c) {year} {holder}
""",

        "AGPL-3.0": """GNU AFFERO GENERAL PUBLIC LICENSE
Version 3, 19 November 2007

Copyright (C) 2007 Free Software Foundation, Inc. <http://fsf.org/>

Everyone is permitted to copy and distribute verbatim copies of this
license document, but changing it is not allowed.

Preamble

The GNU Affero General Public License is a free, copyleft license for
software and other kinds of works, specifically designed to ensure
cooperation with the community in the case of network server software.

The licenses for most software and other practical works are designed
to take away your freedom to share and change the works. By contrast,
our General Public Licenses are intended to guarantee your freedom to
share and change all versions of a program--to make sure it remains free
software for all its users.

When we speak of free software, we are referring to freedom, not price.
Our General Public Licenses are designed to make sure that you have the
freedom to distribute copies of free software (and charge for them if
you wish), that you receive source code or can get it if you want it,
that you can change the software or use pieces of it in new free
programs, and that you know you can do these things.

Developers that use our General Public Licenses protect your rights
with two steps: (1) assert copyright on the software, and (2) offer
you this License which gives you legal permission to copy, distribute
and/or modify the software.

A secondary benefit of defending all users' freedom is that
improvements made in alternate versions of the program, if they
receive widespread use, become available for other developers to
incorporate. Many developers of free software are heartened and
encouraged by the resulting cooperation. However, in the case of
software used on network servers, this result may fail to come about.
The GNU General Public License permits making a modified version and
letting the public access it on a server without ever releasing its
source code to the public.

The GNU Affero General Public License is designed specifically to
ensure that, in such cases, the modified source code becomes available
to the community. It requires the operator of a network server to
provide the source code of the modified version running there to the
users of that server. Therefore, public use of a modified version, on
a publicly accessible server, gives the public access to the source
code of the modified version.

An older license, called the Affero General Public License and
published by Affero, was designed to accomplish similar goals. This is
a different license, not a version of the Affero GPL, but Affero has
released a new version of the Affero GPL which permits relicensing under
this license.

The precise terms and conditions for copying, distribution and
modification follow.

TERMS AND CONDITIONS

0. Definitions.

   "This License" refers to version 3 of the GNU Affero General Public
   License.

   "Copyright" also means copyright-like laws that apply to other kinds
   of works, such as semiconductor masks.

   "The Program" refers to any copyrightable work licensed under this
   License. Each licensee is addressed as "you". "Licensees" and
   "recipients" may be individuals or organizations.

   To "modify" a work means to copy from or adapt all or part of the work
   in a fashion requiring copyright permission, other than the making of
   an exact copy. The resulting work is called a "modified version" of
   the earlier work or a work "based on" the earlier work.

   A "covered work" means either the unmodified Program or a work based
   on the Program.

   To "propagate" a work means to do anything with it that, without
   permission, would make you directly or secondarily liable for
   infringement under applicable copyright law, except executing it on a
   computer or modifying a private copy. Propagation includes copying,
   distribution (with or without modification), making available to the
   public, and in some countries other activities as well.

   To "convey" a work means any kind of propagation that enables other
   parties to make or receive copies. Mere interaction with a user through
   a computer network, with no transfer of a copy, is not conveying.

   An interactive user interface displays "Appropriate Legal Notices"
   to the extent that it includes a convenient and prominently visible
   feature that (1) displays an appropriate copyright notice, and (2)
   tells the user that there is no warranty for the work (except to the
   extent that warranties are provided), that licensees may convey the
   work under this License, and how to view a copy of this License. If
   the interface presents a list of user commands or options, such as a
   menu, a prominent item in the list meets this criterion.

1. Source Code.

   The "source code" for a work means the preferred form of the work
   for making modifications to it. "Object code" means any non-source
   form of a work.

   A "Standard Interface" means an interface that either is an official
   standard defined by a recognized standards body, or, in the case of
   interfaces specified for a particular programming language, one that
   is widely used among developers working in that language.

   The "System Libraries" of an executable work include anything, other
   than the work as a whole, that (a) is included in the normal form of
   packaging a Major Component, but which is not part of that Major
   Component, and (b) serves only to enable use of the work with that
   Major Component, or to implement a Standard Interface for which an
   implementation is available to the public in source code form. A
   "Major Component", in this context, means a major essential component
   (kernel, window system, and so on) of the specific operating system
   (if any) on which the executable work runs, or a compiler used to
   produce the work, or an object code interpreter used to run it.

   The "Corresponding Source" for a work in object code form means all
   the source code needed to generate, install, and (for an executable
   work) run the object code and to modify the work, including scripts to
   control those activities. However, it does not include the work's
   System Libraries, or general-purpose tools or generally available free
   programs which are used unmodified in performing those activities but
   which are not part of the work. For example, Corresponding Source
   includes interface definition files associated with source files for
   the work, and the source code for shared libraries and dynamically
   linked subprograms that the work is specifically designed to require,
   such as by intimate data communication or control flow between those
   subprograms and other parts of the work.

   The Corresponding Source need not include anything that users
   can regenerate automatically from other parts of the Corresponding
   Source.

   The Corresponding Source for a work in source code form is that
   same work.

2. Basic Permissions.

   All rights granted under this License are granted for the term of
   copyright on the Program, and are irrevocable provided the stated
   conditions are met. This License explicitly affirms your unlimited
   permission to run the unmodified Program. The output from running a
   covered work is covered by this License only if the output, given its
   content, constitutes a covered work. This License acknowledges your
   rights of fair use or other equivalent, as provided by copyright law.

   You may make, run and propagate covered works that you do not
   convey, without conditions so long as your license otherwise remains
   in force. You may convey covered works to others for the sole purpose
   of having them make modifications exclusively for you, or provide you
   with facilities for running those works, provided that you comply with
   the terms of this License in conveying all material for which you do
   not control copyright. Those thus making or running the covered works
   for you must do so exclusively on your behalf, under your direction
   and control, on terms that prohibit them from making any copies of
   your copyrighted material outside their relationship with you.

   Conveying under any other circumstances is permitted solely under
   the conditions stated below. Sublicensing is not allowed; section 10
   makes it unnecessary.

3. Protecting Users' Legal Rights From Anti-Circumvention Law.

   No covered work shall be deemed part of an effective technological
   measure under any applicable law fulfilling obligations under article
   11 of the WIPO copyright treaty adopted on 20 December 1996, or
   similar laws prohibiting or restricting circumvention of such
   measures.

   When you convey a covered work, you waive any legal power to forbid
   circumvention of technological measures to the extent such circumvention
   is effected by exercising rights under this License with respect to
   the covered work, and you disclaim any intention to limit operation or
   modification of the work as a means of enforcing, against the work's
   users, your or third parties' legal rights to forbid circumvention of
   technological measures.

4. Conveying Verbatim Copies.

   You may convey verbatim copies of the Program's source code as you
   receive it, in any medium, provided that you conspicuously and
   appropriately publish on each copy an appropriate copyright notice;
   keep intact all notices stating that this License and any
   non-permissive terms added in accord with section 7 apply to the code;
   keep intact all notices of the absence of any warranty; and give all
   recipients a copy of this License along with the Program.

   You may charge any price or no price for each copy that you convey,
   and you may offer support or warranty protection for a fee.

5. Conveying Modified Source Versions.

   You may convey a work based on the Program, or the modifications to
   produce it from the Program, in the form of source code under the
   terms of section 4, provided that you also meet all of these conditions:

   a) The work must carry prominent notices stating that you modified
       it, and giving a relevant date.

   b) The work must carry prominent notices stating that it is
       released under this License and any conditions added under section
       7. This requirement modifies the requirement in section 4 to
       "keep intact all notices".

   c) You must license the entire work, as a whole, under this
       License to anyone who comes into possession of a copy. This
       License will therefore apply, along with any applicable section 7
       additional terms, to the whole of the work, and all its parts,
       regardless of how they are packaged. This License gives no
       permission to license the work in any other way, but it does not
       invalidate such permission if you have separately received it.

   d) If the work has interactive user interfaces, each must display
       Appropriate Legal Notices; however, if the Program has interactive
       interfaces that do not display Appropriate Legal Notices, your
       work need not make them do so.

   A compilation of a covered work with other separate and independent
   works, which are not by their nature extensions of the covered work,
   and which are not combined with it such as to form a larger program,
   in or on a volume of a storage or distribution medium, is called an
   "aggregate" if the compilation and its resulting copyright are not
   used to limit the access or legal rights of the compilation's users
   beyond what the individual works permit. Inclusion of a covered work
   in an aggregate does not cause this License to apply to the other
   parts of the aggregate.

6. Conveying Non-Source Forms.

   You may convey a covered work in object code form under the terms
   of sections 4 and 5, provided that you also convey the
   machine-readable Corresponding Source under the terms of this License,
   in one of these ways:

   a) Convey the object code in, or embodied in, a physical product
       (including a physical distribution medium), accompanied by the
       Corresponding Source fixed on a durable physical medium
       customarily used for software interchange.

   b) Convey the object code in, or embodied in, a physical product
       (including a physical distribution medium), accompanied by a
       written offer, valid for at least three years and valid for as
       long as you offer spare parts or customer support for that product
       model, to give anyone who possesses the object code either (1) a
       copy of the Corresponding Source for all the software in the
       product that is covered by this License, on a durable physical
       medium customarily used for software interchange, for a price no
       more than your reasonable cost of physically performing this
       conveying of source, or (2) access to copy the
       Corresponding Source from a network server at no charge.

   c) Convey individual copies of the object code with a copy of the
       written offer to provide the Corresponding Source. This
       alternative is allowed only occasionally and noncommercially, and
       only if you received the object code with such an offer, in accord
       with subsection 6b.

   d) Convey the object code by offering access from a designated
       place (gratis or for a charge), and offer equivalent access to the
       Corresponding Source in the same way through the same place at no
       further charge. You need not require recipients to copy the
       Corresponding Source along with the object code. If the place to
       copy the object code is a network server, the Corresponding Source
       may be on a different server (operated by you or a third party)
       that supports equivalent copying facilities, provided you maintain
       clear directions next to the object code saying where to find the
       Corresponding Source. Regardless of what server hosts the
       Corresponding Source, you remain obligated to ensure that it is
       available for as long as needed to satisfy these requirements.

   e) Convey the object code using peer-to-peer transmission, provided
       you inform other peers where the object code and Corresponding
       Source of the work are being offered to the general public at no
       charge under subsection 6d.

   A separable portion of the object code, whose source code is excluded
   from the Corresponding Source as a System Library, need not be
   included in conveying the object code work.

   A "User Product" is either (1) a "consumer product", which means any
   tangible personal property which is normally used for personal, family,
   or household purposes, or (2) anything designed or sold for incorporation
   into a dwelling. In determining whether a product is a consumer product,
   doubtful cases shall be resolved in favor of coverage. For a particular
   product received by a particular user, "normally used" refers to a
   typical or common use of that class of product, regardless of the status
   of the particular user or of the way in which the particular user
   actually uses, or expects or is expected to use, the product. A product
   is a consumer product regardless of whether the product has substantial
   commercial, industrial or non-consumer uses, unless such uses represent
   the only significant mode of use of the product.

   "Installation Information" for a User Product means any methods,
   procedures, authorization keys, or other information required to install
   and execute modified versions of a covered work in that User Product from
   a modified version of its Corresponding Source. The information must
   suffice to ensure that the continued functioning of the modified object
   code is in no case prevented or interfered with solely because
   modification has been made.

   If you convey an object code work under this section in, or with, or
   specifically for use in, a User Product, and the conveying occurs as
   part of a transaction in which the right of possession and use of the
   User Product is transferred to the recipient in perpetuity or for a
   fixed term (regardless of how the transaction is characterized), the
   Corresponding Source conveyed under this section must be accompanied
   by the Installation Information. But this requirement does not apply
   if neither you nor any third party retains the ability to install
   modified object code on the User Product (for example, the work has
   been installed in ROM).

   The requirement to provide Installation Information does not include a
   requirement to continue to provide support service, warranty, or updates
   for a work that has been modified or installed by the recipient, or for
   the User Product in which it has been modified or installed. Access to a
   network may be denied when the modification itself materially and
   adversely affects the operation of the network or violates the rules and
   protocols for communication across the network.

   Corresponding Source conveyed, and Installation Information provided,
   in accord with this section must be in a format that is publicly
   documented (and with an implementation available to the public in
   source code form), and must require no special password or key for
   unpacking, reading or copying.

7. Additional Terms.

   "Additional permissions" are terms that supplement the terms of this
   License by making exceptions from one or more of its conditions.
   Additional permissions that are applicable to the entire Program shall
   be treated as though they were included in this License, to the extent
   that they are valid under applicable law. If additional permissions
   apply only to part of the Program, that part may be used separately
   under those permissions, but the entire Program remains governed by
   this License without regard to the additional permissions.

   When you convey a copy of a covered work, you may at your option
   remove any additional permissions from that copy, or from any part of
   it. (Additional permissions may be written to require their own
   removal in certain cases when you modify the work.) You may place
   additional permissions on material, added by you to a covered work,
   for which you have or can give appropriate copyright permission.

   Notwithstanding any other provision of this License, for material you
   add to a covered work, you may (if authorized by the copyright holders of
   that material) supplement the terms of this License with terms:

   a) Disclaiming warranty or limiting liability differently from the
       terms of sections 15 and 16 of this License; or

   b) Requiring preservation of specified reasonable legal notices or
       author attributions in that material or in the Appropriate Legal
       Notices displayed by works containing it; or

   c) Prohibiting misrepresentation of the origin of that material, or
       requiring that modified versions of such material be marked in
       reasonable ways as different from the original version; or

   d) Limiting the use for publicity purposes of names of licensors or
       authors of the material; or

   e) Declining to grant rights under trademark law for use of some
       trade names, trademarks, or service marks; or

   f) Requiring indemnification of licensors and authors of that
       material by anyone who conveys the material (or modified versions of
       it) with contractual assumptions of liability to the recipient, for
       any liability that these contractual assumptions directly impose on
       those licensors and authors.

   All other non-permissive additional terms are considered "further
   restrictions" within the meaning of section 10. If the Program as you
   received it, or any part of it, contains a notice stating that it is
   governed by this License along with a term that is a further
   restriction, you may remove that term. If a license document contains
   a further restriction but permits relicensing or conveying under this
   License, you may add to a covered work material governed by the terms
   of that license document, provided that the further restriction does
   not survive such relicensing or conveying.

   If you add terms to a covered work in accord with this section, you
   must place, in the relevant source files, a statement of the
   additional terms that apply to those files, or a notice indicating
   where to find the applicable terms.

   Additional terms, permissive or non-permissive, may be stated in the
   form of a separately written license, or stated as exceptions;
   the above requirements apply either way.

8. Termination.

   You may not propagate or modify a covered work except as expressly
   provided under this License. Any attempt otherwise to propagate or
   modify it is void, and will automatically terminate your rights under
   this License (including any patent licenses granted under the third
   paragraph of section 11).

   However, if you cease all violation of this License, then your
   license from a particular copyright holder is reinstated (a)
   provisionally, unless and until the copyright holder explicitly and
   finally terminates your license, and (b) permanently, if the copyright
   holder fails to notify you of the violation by some reasonable means
   prior to 60 days after the cessation.

   Moreover, your license from a particular copyright holder is
   reinstated permanently if the copyright holder notifies you of the
   violation by some reasonable means, this is the first time you have
   received notice of violation of this License (for any work) from that
   copyright holder, and you cure the violation prior to 30 days after
   your receipt of the notice.

   Termination of your rights under this section does not terminate the
   licenses of parties who have received copies or rights from you under
   this License. If your rights have been terminated and not permanently
   reinstated, you do not qualify to receive new licenses for the same
   material under section 10.

9. Acceptance Not Required for Having Copies.

   You are not required to accept this License in order to receive or
   run a copy of the Program. Ancillary propagation of a covered work
   occurring solely as a consequence of using peer-to-peer transmission
   to receive a copy likewise does not require acceptance. However,
   nothing other than this License grants you permission to propagate or
   modify any covered work. These actions infringe copyright if you do
   not accept this License. Therefore, by modifying or propagating a
   covered work, you indicate your acceptance of this License to do so.

10. Automatic Licensing of Downstream Recipients.

    Each time you convey a covered work, the recipient automatically
    receives a license from the original licensors, to run, modify and
    propagate that work, subject to this License. You are not responsible
    for enforcing compliance by third parties with this License.

    An "entity transaction" is a transaction transferring control of an
    organization, or substantially all assets of one, or subdividing an
    organization, or merging organizations. If propagation of a covered
    work results from an entity transaction, each party to that
    transaction who receives a copy of the work also receives whatever
    licenses to the work the party's predecessor in interest had or could
    give under the previous paragraph, plus a right to possession of the
    Corresponding Source of the work from the predecessor in interest, if
    the predecessor has it or can get it with reasonable efforts.

    You may not impose any further restrictions on the exercise of the
    rights granted or affirmed under this License. For example, you may
    not impose a license fee, royalty, or other charge for exercise of
    rights granted under this License, and you may not initiate litigation
    (including a cross-claim or counterclaim in a lawsuit) alleging that
    any patent claim is infringed by making, using, selling, offering for
    sale, or importing the Program or any portion of it.

11. Patents.

    A "contributor" is a copyright holder who authorizes use under this
    License of the Program or a work on which the Program is based. The
    work thus licensed is called the contributor's "contributor version".

    A contributor's "essential patent claims" are all patent claims
    owned or controlled by the contributor, whether already acquired or
    hereafter acquired, that would be infringed by some manner, permitted
    by this License, of making, using, or selling its contributor version,
    but do not include claims that would be infringed only as a
    consequence of further modification of the contributor version. For
    purposes of this definition, "control" includes the right to grant
    patent sublicenses in a manner consistent with the requirements of
    this License.

    Each contributor grants you a non-exclusive, worldwide, royalty-free
    patent license under the contributor's essential patent claims, to
    make, use, sell, offer for sale, import and otherwise run, modify and
    propagate the contents of its contributor version.

    In the following three paragraphs, a "patent license" is any express
    agreement or commitment, however denominated, not to enforce a patent
    (such as an express permission to practice a patent or covenant not to
    sue for patent infringement). To "grant" such a patent license to a
    party means to make such an agreement or commitment not to enforce a
    patent against the party.

    If you convey a covered work, knowingly relying on a patent license,
    and the Corresponding Source of the work is not available for anyone
    to copy, free of charge and under the terms of this License, through a
    publicly available network server or other readily accessible means,
    then you must either (1) cause the Corresponding Source to be so
    available, or (2) arrange to deprive yourself of the benefit of the
    patent license for this particular work, or (3) arrange, in a manner
    consistent with the requirements of this License, to extend the patent
    license to downstream recipients. "Knowingly relying" means you have
    actual knowledge that, but for the patent license, your conveying the
    covered work in a country, or your recipient's use of the covered work
    in a country, would infringe one or more identifiable patents in that
    country that you have reason to believe are valid.

    If, pursuant to or in connection with a single transaction or
    arrangement, you convey, or propagate by procuring conveyance of, a
    covered work, and grant a patent license to some of the parties
    receiving the covered work authorizing them to use, propagate, modify
    or convey a specific copy of the covered work, then the patent license
    you grant is automatically extended to all recipients of the covered
    work and works based on it.

    A patent license is "discriminatory" if it does not include within
    the scope of its coverage, prohibits the exercise of, or is
    conditioned on the non-exercise of one or more of the rights that are
    specifically granted under this License. You may not convey a covered
    work if you are a party to an arrangement with a third party that is
    in the business of distributing software, under which you make payment
    to the third party based on the extent of your activity of conveying
    the work, and under which the third party grants, to any of the
    parties who would receive the covered work from you, a discriminatory
    patent license (a) in connection with copies of the covered work
    conveyed by you (or copies made from those copies), or (b) primarily
    for and in connection with specific products or compilations that
    contain the covered work, unless you entered into that arrangement,
    or that patent license was granted, prior to 28 March 2007.

    Nothing in this License shall be construed as excluding or limiting
    any implied license or other defenses to infringement that may
    otherwise be available to you under applicable patent law.

12. No Surrender of Others' Freedom.

    If conditions are imposed on you (whether by court order, agreement or
    otherwise) that contradict the conditions of this License, they do not
    excuse you from the conditions of this License. If you cannot convey a
    covered work so as to satisfy simultaneously your obligations under this
    License and any other pertinent obligations, then as a consequence you may
    not convey it at all. For example, if you agree to terms that obligate you
    to collect a royalty for further conveying from those to whom you convey
    the Program, the only way you could satisfy both those terms and this
    License would be to refrain entirely from conveying the Program.

13. Remote Network Interaction; Use with the GNU General Public License.

    Notwithstanding any other provision of this License, if you modify the
    Program, your modified version must prominently offer all users
    interacting with it remotely through a computer network (if your version
    supports such interaction) an opportunity to receive the Corresponding
    Source of your version by providing access to the Corresponding Source
    from a network server at no charge, through some standard or customary
    means of facilitating copying of software. This Corresponding Source
    shall include the Corresponding Source for any work covered by version 3
    of the GNU General Public License that is incorporated pursuant to the
    following paragraph.

    Notwithstanding any other provision of this License, you have permission
    to link or combine any covered work with a work licensed under version 3
    of the GNU General Public License into a single combined work, and to
    convey the resulting work. The terms of this License will continue to
    apply to the part which is the covered work, but the work with which it is
    combined will remain governed by version 3 of the GNU General Public
    License.

14. Revised Versions of this License.

    The Free Software Foundation may publish revised and/or new versions of
    the GNU Affero General Public License from time to time. Such new versions
    will be similar in spirit to the present version, but may differ in detail to
    address new problems or concerns.

    Each version is given a distinguishing version number. If the
    Program specifies that a certain numbered version of the GNU Affero General
    Public License "or any later version" applies to it, you have the
    option of following the terms and conditions either of that numbered
    version or of any later version published by the Free Software
    Foundation. If the Program does not specify a version number of the
    GNU Affero General Public License, you may choose any version ever published
    by the Free Software Foundation.

    If the Program specifies that a proxy can decide which future
    versions of the GNU Affero General Public License can be used, that proxy's
    public statement of acceptance of a version permanently authorizes you
    to choose that version for the Program.

    Later license versions may give you additional or different
    permissions. However, no additional obligations are imposed on any
    author or copyright holder as a result of your choosing to follow a
    later version.

15. Disclaimer of Warranty.

    THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY
    APPLICABLE LAW. EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT
    HOLDERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY
    OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO,
    THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
    PURPOSE. THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE PROGRAM
    IS WITH YOU. SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF
    ALL NECESSARY SERVICING, REPAIR OR CORRECTION.

16. Limitation of Liability.

    IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
    WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MODIFIES AND/OR CONVEYS
    THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES, INCLUDING ANY
    GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE
    USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF
    DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD
    PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS),
    EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF
    SUCH DAMAGES.

17. Interpretation of Sections 15 and 16.

    If the disclaimer of warranty and limitation of liability provided
    above cannot be given local legal effect according to their terms,
    reviewing courts shall apply local law that most closely approximates
    an absolute waiver of all civil liability in connection with the
    Program, unless a warranty or assumption of liability accompanies a
    copy of the Program in return for a fee.

END OF TERMS AND CONDITIONS

Copyright (C) {year}  {holder}

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
""",

        "MIT-0": """MIT No Attribution

Copyright (c) {year} {holder}

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
""",

        "Unlicense": """This is free and unencumbered software released into the public domain.

Anyone is free to copy, modify, publish, use, compile, sell, or
distribute this software, either in source code form or as a compiled
binary, for any purpose, commercial or non-commercial, and by any
means.

In jurisdictions that recognize copyright laws, the author or authors
of this software dedicate any and all copyright interest in the
software to the public domain. We make this dedication for the benefit
of the public at large and to the detriment of our heirs and
successors. We intend this dedication to be an overt act of
relinquishment in perpetuity of all present and future rights to this
software under copyright law.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

For more information, please refer to <http://unlicense.org/>
""",

        "CC0-1.0": """Creative Commons Legal Code

CC0 1.0 Universal

    CREATIVE COMMONS CORPORATION IS NOT A LAW FIRM AND DOES NOT PROVIDE
    LEGAL SERVICES. DISTRIBUTION OF THIS DOCUMENT DOES NOT CREATE AN
    ATTORNEY-CLIENT RELATIONSHIP. CREATIVE COMMONS PROVIDES THIS
    INFORMATION ON AN "AS-IS" BASIS. CREATIVE COMMONS MAKES NO WARRANTIES
    REGARDING THE USE OF THIS DOCUMENT OR THE INFORMATION OR WORKS
    PROVIDED HEREUNDER, AND DISCLAIMS LIABILITY FOR DAMAGES RESULTING FROM
    THE USE OF THIS DOCUMENT OR THE INFORMATION OR WORKS PROVIDED
    HEREUNDER.

Statement of Purpose

The laws of most jurisdictions throughout the world automatically confer
exclusive Copyright and Related Rights (defined below) upon the creator
and subsequent owner(s) (each and all, an "owner") of an original work of
authorship and/or a database (each, a "Work").

Certain owners wish to permanently relinquish those rights to a Work for
the purpose of contributing to a commons of creative, cultural and
scientific works ("Commons") that the public can reliably and without fear
of later claims of infringement build upon, modify, incorporate in other
works, reuse and redistribute as freely as possible in any form whatsoever
and for any purposes, including without limitation commercial purposes.
These owners may contribute to the Commons to promote the ideal of a free
culture and the further production of creative, cultural and scientific
works, or to gain reputation or greater distribution for their Work in
part through the use and efforts of others.

For these and/or other purposes and motivations, and without any
expectation of additional consideration or compensation, the person
associating CC0 with a Work (the "Affirmer"), to the extent that he or she
is an owner of Copyright and Related Rights in the Work, voluntarily
elects to apply CC0 to the Work and publicly distribute the Work under its
terms, with knowledge of his or her Copyright and Related Rights in the
Work and the meaning and intended legal effect of CC0 on those rights.

1. Copyright and Related Rights. A Work made available under CC0 may be
protected by copyright and related or neighboring rights ("Copyright and
Related Rights"). Copyright and Related Rights include, but are not limited
to, the following:

  i. the right to reproduce, adapt, distribute, perform, display,
     communicate, and translate a Work;
 ii. moral rights retained by the original author(s) and/or performer(s);
iii. publicity and privacy rights pertaining to a person's image or
     likeness depicted in a Work;
 iv. rights protecting against unfair competition in regards to a Work,
     subject to the limitations in paragraph 4(a), below;
  v. rights protecting the extraction, dissemination, use and reuse of data
     in a Work;
 vi. database rights (such as those arising under Directive 96/9/EC of the
     European Parliament and of the Council of 11 March 1996 on the legal
     protection of databases, and under any national implementation
     thereof, including any amended or successor version of such
     directive); and
vii. other similar, equivalent or corresponding rights throughout the
     world based on applicable law or treaty, and any national
     implementations thereof.

2. Waiver. To the greatest extent permitted by, but not in contravention
of, applicable law, Affirmer hereby overtly, fully, permanently,
irrevocably and unconditionally waives, abandons, and surrenders all of
Affirmer's Copyright and Related Rights and associated claims and causes
of action, whether now known or unknown (including existing as well as
future claims and causes of action), in the Work (i) in all territories
worldwide, (ii) for the maximum duration provided by applicable law or
treaty (including future time extensions), (iii) in any current or future
medium and for any number of copies, and (iv) for any purpose whatsoever,
including without limitation commercial, advertising or promotional
purposes (the "Waiver"). Affirmer makes the Waiver for the benefit of each
member of the public at large and to the detriment of Affirmer's heirs and
successors, fully intending that such Waiver shall not be subject to
revocation, rescission, cancellation, termination, or any other legal or
equitable action to disrupt the quiet enjoyment of the Work by the public
as contemplated by Affirmer's express Statement of Purpose.

3. Public License Fallback. Should any part of the Waiver for any reason
be judged legally invalid or ineffective under applicable law, then the
Waiver shall be preserved to the maximum extent permitted taking into
account Affirmer's express Statement of Purpose. In addition, to the
extent the Waiver is so judged Affirmer hereby grants to each affected
person a royalty-free, non transferable, non sublicensable, non exclusive,
irrevocable and unconditional license to exercise Affirmer's Copyright and
Related Rights in the Work (i) in all territories worldwide, (ii) for the
maximum duration provided by applicable law or treaty (including future
time extensions), (iii) in any current or future medium and for any number
of copies, and (iv) for any purpose whatsoever, including without
limitation commercial, advertising or promotional purposes (the
"License"). The License shall be deemed effective as of the date CC0 was
applied by Affirmer to the Work. Should any part of the License for any
reason be judged legally invalid or ineffective under applicable law, such
partial invalidity or ineffectiveness shall not invalidate the remainder
of the License, and in such case Affirmer hereby affirms that he or she
will not (i) exercise any of his or her remaining Copyright and Related
Rights in the Work or (ii) assert any associated claims and causes of
action with respect to the Work, in either case contrary to Affirmer's
express Statement of Purpose.

4. Limitations and Disclaimers.

 a. No trademark or patent rights held by Affirmer are waived, abandoned,
    surrendered, licensed or otherwise affected by this document.
 b. Affirmer offers the Work as-is and makes no representations or
    warranties of any kind concerning the Work, express, implied,
    statutory or otherwise, including without limitation warranties of
    title, merchantability, fitness for a particular purpose, non
    infringement, or the absence of latent or other defects, accuracy, or
    the present or absence of errors, whether or not discoverable, all to
    the greatest extent permissible under applicable law.
 c. Affirmer disclaims responsibility for clearing rights of other persons
    that may apply to the Work or any use thereof, including without
    limitation any person's Copyright and Related Rights in the Work.
    Further, Affirmer disclaims responsibility for obtaining any necessary
    consents, permissions or other rights required for any use of the
    Work.
 d. Affirmer understands and acknowledges that Creative Commons is not a
    party to this document and has no duty or obligation with respect to
    this CC0 or use of the Work.

Copyright (c) {year} {holder}
""",

        "BSL-1.0": """Boost Software License - Version 1.0 - August 17th, 2003

Permission is hereby granted, free of charge, to any person or organization
obtaining a copy of the software and accompanying documentation covered by
this license (the "Software") to use, reproduce, display, distribute,
execute, and transmit the Software, and to prepare derivative works of the
Software, and to permit third-parties to whom the Software is furnished to
do so, all subject to the following:

The copyright notices in the Software and this entire statement, including
the above license grant, this restriction and the following disclaimer,
must be included in all copies of the Software, in whole or in part, and
all derivative works of the Software, unless such copies or derivative
works are solely in the form of machine-executable object code generated by
a source language processor.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT. IN NO EVENT
SHALL THE COPYRIGHT HOLDERS OR ANYONE DISTRIBUTING THE SOFTWARE BE LIABLE
FOR ANY DAMAGES OR OTHER LIABILITY, WHETHER IN CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.

Copyright (c) {year} {holder}
""",

        "Zlib": """The zlib/libpng License

Copyright (c) {year} {holder}

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software in a
   product, an acknowledgment in the product documentation would be
   appreciated but is not required.

2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.
""",
    }


def license_template(
    license_type: str = "MIT",
    holder: str = "Your Name",
    year: Optional[int] = None,
    project_name: Optional[str] = None,
    organization: Optional[str] = None,
    email: Optional[str] = None,
    include_disclaimer: bool = True,
    include_warranty: bool = True,
    add_timestamp_comment: bool = True,
    custom_notice: Optional[str] = None,
    extra_placeholders: Optional[Dict[str, str]] = None,
    validate_spdx: bool = True,
) -> str:
    """
    Generate a complete LICENSE file template for common open-source licenses.

    This function provides full license texts for major open-source licenses,
    following SPDX identifiers and standard legal formats. It supports template
    substitution for copyright holders, years, project names, and other
    customizable elements.

    Parameters
    ----------
    license_type : str, default="MIT"
        License type or SPDX identifier. Supported licenses:
        - "MIT": MIT License (permissive, simple)
        - "Apache-2.0": Apache License 2.0 (permissive, patent protection)
        - "GPL-3.0": GNU General Public License v3.0 (copyleft)
        - "GPL-3.0-or-later": GNU GPL v3.0 or any later version
        - "LGPL-3.0": GNU Lesser GPL v3.0 (library copyleft)
        - "AGPL-3.0": GNU Affero GPL v3.0 (network copyleft)
        - "BSD-3-Clause": BSD 3-Clause (permissive, no endorsement)
        - "BSD-2-Clause": BSD 2-Clause (simplified BSD)
        - "ISC": ISC License (simplified MIT-like)
        - "MPL-2.0": Mozilla Public License 2.0 (file-level copyleft)
        - "MIT-0": MIT No Attribution (most permissive)
        - "Unlicense": Public domain dedication
        - "CC0-1.0": Creative Commons Zero (public domain)
        - "BSL-1.0": Boost Software License 1.0 (permissive)
        - "Zlib": zlib/libpng License (permissive)
        
    holder : str, default="Your Name"
        Copyright holder name. Usually the person, organization, or entity
        holding the copyright. For multiple holders, use a comma-separated list.
        
    year : int, optional
        Copyright year. Defaults to current year. For multiple years,
        use format like "2020-2024" in the string directly.
        
    project_name : str, optional
        Project name. Used in some licenses (e.g., Apache 2.0 requires this
        in the NOTICE file, GPL includes it in headers). If not provided,
        attempts to use holder name or leaves blank.
        
    organization : str, optional
        Organization name. Used in some licenses for attribution.
        
    email : str, optional
        Contact email address. Included in some license headers for
        maintaining contact information.
        
    include_disclaimer : bool, default=True
        Include warranty disclaimer section. Some licenses require this,
        others make it optional. For licenses that require it, this is
        always included regardless of this setting.
        
    include_warranty : bool, default=True
        Include "AS IS" warranty statement. Most open-source licenses
        include this to limit liability.
        
    add_timestamp_comment : bool, default=True
        Add a comment with generation timestamp at the top of the file.
        Useful for tracking when the license was generated.
        
    custom_notice : str, optional
        Additional custom notice text to include at the top of the license.
        Useful for adding organization-specific disclaimers or additional
        copyright notices.
        
    extra_placeholders : dict, optional
        Additional placeholder replacements. Keys are placeholder names
        (without braces), values are replacement strings. Used for custom
        license modifications or language translations.
        
    validate_spdx : bool, default=True
        Validate that the license_type is a valid SPDX identifier.
        If False, allows custom license names (use with caution).

    Returns
    -------
    str
        Complete license text ready to be written to a LICENSE file.

    Raises
    ------
    ValueError
        If license_type is not supported (and validate_spdx is True).
        If required placeholders are missing.

    Examples
    --------
    Basic MIT license:
    >>> mit_license = license_template(
    ...     license_type="MIT",
    ...     holder="Jane Doe",
    ...     year=2024
    ... )
    >>> print(mit_license[:100])

    Apache 2.0 with organization:
    >>> apache_license = license_template(
    ...     license_type="Apache-2.0",
    ...     holder="Jane Doe",
    ...     organization="Example Corp",
    ...     project_name="my-awesome-project",
    ...     year=2024
    ... )

    GPL v3 with copyright header:
    >>> gpl_license = license_template(
    ...     license_type="GPL-3.0",
    ...     holder="Jane Doe",
    ...     year=2024,
    ...     custom_notice="Additional terms: You must preserve this notice."
    ... )

    Using extra placeholders for custom templates:
    >>> custom_license = license_template(
    ...     license_type="MIT",
    ...     holder="Jane Doe",
    ...     extra_placeholders={"additional_clause": "Special terms apply."}
    ... )

    Notes
    -----
    - All license texts are taken from official sources (OSI, FSF, etc.)
    - The function ensures proper line endings and formatting
    - Placeholders are replaced in the order: standard placeholders first,
      then extra_placeholders
    - For GPL-family licenses, the full text is included as required by
      the license terms
    - SPDX identifiers are used for license detection and compatibility
      checking

    See Also
    --------
    pyproject_template : Generate pyproject.toml with license metadata
    spdx.org : Official SPDX license list
    choosealicense.com : License comparison and selection guide
    """

    # Set defaults
    year = year or datetime.now().year
    extra_placeholders = extra_placeholders or {}
    
    # Validate license type
    if validate_spdx and license_type not in LICENSE_SPDX:
        supported = ", ".join(LICENSE_SPDX.keys())
        raise ValueError(
            f"Unsupported license type: '{license_type}'. "
            f"Supported licenses: {supported}"
        )
    
    # Get template
    if license_type not in LicenseTemplate.TEMPLATES:
        raise ValueError(f"License template not available for: {license_type}")
    
    template = LicenseTemplate.TEMPLATES[license_type]
    
    # Prepare placeholders
    placeholders = {
        "year": str(year),
        "holder": holder,
        "project_name": project_name or holder,
        "organization": organization or holder,
        "email": email or "",
        "full_name": holder,  # Some licenses use this
    }
    
    # Add custom placeholders (override if needed)
    placeholders.update(extra_placeholders)
    
    # Replace all placeholders
    for key, value in placeholders.items():
        if value:  # Only replace if value is provided
            template = template.replace(f"{{{key}}}", value)
    
    # Add timestamp comment if requested
    timestamp_comment = ""
    if add_timestamp_comment:
        timestamp_comment = (
            f"# License generated by license_template on "
            f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"# SPDX-License-Identifier: {license_type}\n"
            f"# License name: {LICENSE_SPDX.get(license_type, license_type)}\n"
        )
        if custom_notice:
            timestamp_comment += f"# Notice: {custom_notice}\n"
        timestamp_comment += "\n"
    
    # Add custom notice if provided
    if custom_notice and not add_timestamp_comment:
        template = f"# {custom_notice}\n\n{template}"
    
    # Combine everything
    full_license = timestamp_comment + template
    
    # Ensure proper line endings
    full_license = full_license.replace("\r\n", "\n").replace("\r", "\n")
    
    # Add final newline if missing
    if not full_license.endswith("\n"):
        full_license += "\n"
    
    return full_license


def write_license(path: Union[str, Path] = "LICENSE", **kwargs) -> None:
    """
    Generate a LICENSE file and write it directly to disk.
    
    This is a convenience wrapper around license_template() that handles
    file writing with proper encoding and error handling.
    
    Parameters
    ----------
    path : str or Path, default="LICENSE"
        Path where to write the LICENSE file. Can be a string or Path object.
        If a directory is provided, writes to 'LICENSE' in that directory.
        If a file path is provided, writes to that specific file.
        
    **kwargs
        Additional arguments passed to license_template(). See license_template()
        for all available parameters.
        
    Returns
    -------
    None
    
    Raises
    ------
    IOError
        If the file cannot be written (permission denied, disk full, etc.)
        
    Examples
    --------
    Write MIT license to current directory:
    >>> write_license(license_type="MIT", holder="Jane Doe", year=2024)
    
    Write Apache 2.0 license to a specific location:
    >>> write_license("docs/LICENSE", license_type="Apache-2.0", holder="Example Corp")
    
    Write GPL license with custom notice:
    >>> write_license(
    ...     "LICENSE",
    ...     license_type="GPL-3.0",
    ...     holder="Jane Doe",
    ...     custom_notice="This project is provided as-is under the GPL v3."
    ... )
    
    Notes
    -----
    - The file is written with UTF-8 encoding
    - Existing files are overwritten without warning
    - The directory is created if it doesn't exist
    """
    path_obj = Path(path)
    
    # If path is a directory, append LICENSE
    if path_obj.is_dir() or (not path_obj.suffix and path_obj.name.upper() != "LICENSE"):
        path_obj = path_obj / "LICENSE"
    
    # Ensure parent directory exists
    path_obj.parent.mkdir(parents=True, exist_ok=True)
    
    # Generate license content
    content = license_template(**kwargs)
    
    # Write to file
    path_obj.write_text(content, encoding="utf-8")


def detect_license_from_pyproject(pyproject_path: Union[str, Path] = "pyproject.toml") -> Optional[Dict[str, str]]:
    """
    Detect license information from an existing pyproject.toml file.
    
    This helper function reads a pyproject.toml file and extracts license
    information that can be used to generate a LICENSE file.
    
    Parameters
    ----------
    pyproject_path : str or Path, default="pyproject.toml"
        Path to the pyproject.toml file.
        
    Returns
    -------
    dict or None
        Dictionary with license information if found:
        - "license_type": SPDX license identifier
        - "holder": Copyright holder
        - "year": Year from copyright if found
        Returns None if no license information is found.
        
    Examples
    --------
    >>> license_info = detect_license_from_pyproject()
    >>> if license_info:
    ...     write_license(**license_info)
    """
    import tomllib
    
    path = Path(pyproject_path)
    if not path.exists():
        return None
    
    try:
        with open(path, "rb") as f:
            data = tomllib.load(f)
        
        project = data.get("project", {})
        license_info = project.get("license", {})
        
        if not license_info:
            return None
        
        license_type = license_info.get("text") or license_info.get("file", "").replace(".txt", "").replace("LICENSE", "").strip()
        
        # Try to extract holder from authors
        authors = project.get("authors", [])
        holder = "Unknown"
        if authors and isinstance(authors, list):
            first_author = authors[0]
            if isinstance(first_author, dict):
                holder = first_author.get("name", "Unknown")
            else:
                holder = first_author
        
        return {
            "license_type": license_type,
            "holder": holder,
            "year": datetime.now().year,
        }
    except (tomllib.TOMLDecodeError, KeyError, IndexError):
        return None


